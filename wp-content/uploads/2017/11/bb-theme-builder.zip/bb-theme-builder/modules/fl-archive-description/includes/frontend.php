<?php

echo get_the_archive_description();
