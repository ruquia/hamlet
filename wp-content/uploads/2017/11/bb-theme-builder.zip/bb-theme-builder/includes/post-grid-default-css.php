.fl-post-grid-post {
    font-size: 14px;
}
.fl-post-text {
    padding: 20px;
}
.fl-post-title {
    font-size: 20px;
	line-height: 26px;
	margin: 0;
	padding: 0 0 5px;
}
.fl-post-meta {
    padding: 0 0 15px;
}