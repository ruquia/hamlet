<?php

echo FLPageDataWooCommerce::get_product_meta();
